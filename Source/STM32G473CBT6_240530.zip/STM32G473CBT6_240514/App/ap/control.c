/*
 * control.c
 *
 *  Created on: May 10, 2024
 *      Author: user
 */


#include "control.h"
#include "hw_def.h"
#include "cli.h"
#include "adc.h"
#include "dac.h"
#include "lcd.h"
#include "uart.h"
#include "qbuffer.h"




extern TIM_HandleTypeDef htim7;
extern DAC_HandleTypeDef hdac1;
extern DAC_HandleTypeDef hdac2;
extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef hdma_usart3_tx;



static bool    is_init            = false;
const uint32_t multi_sampling_num = 3;              // rms 측정시 파형 획득 횟수
const uint32_t lcd_update_period  = 500;            // ms
const uint8_t  adc_ch_max         = 3;              // ch1: AIN0(VRMS1), ch2: AIN1(VRMS2), ch11: IPP/IPN(IRMS)
const uint16_t control_freq       = 10000;          // 제어 주기 10Khz
const float    vpp_max            = 20.0f;          // vpp
const float    vpeak_max          = 10.0f;          // vpp * 1/2
float          ipeak_max          = 5.0f;           // [A]


float          vpp_out            = 5.0f;           // vpp (default 5Vpp)
float          vpp_out_wave       = 5.0f;           // vpp (default 5Vpp)
float          vpp_out_ready      = 5.0f;           // vpp (default 5Vpp)
float          vpp_set_out        = 2.0f;           // vpp (default 5Vpp)

uint16_t 	   	freq       		  = 30;             // dac freq hz (default 30hz)
uint16_t 	   	freq_wave         = 30;             // dac freq hz (default 30hz)
uint16_t 		freq_ready        = 30;             // dac freq hz (default 30hz)
uint16_t		freq_set          = 30;             // dac freq hz (default 30hz)


uint8_t istate = 0;

uint32_t adc_value[3];                              // idx 0: AIN0(VRMS1), 1: AIN1(VRMS2), 2: IPP/IPN(IRMS)
uint32_t dac_out_value = 4096;                       // dac output value


uint32_t sample_max = 100;                          // 파형 생성시 1주기를 만들기 위한 샘플 수, control_freq/freq, 50(200hz) ~ 10000(1hz).

float vrms[2] = {0.0f, 0.0f};                       // [V] Vrms1 (AIN0), Vrms2(AIN1)
float irms    = 0.0f;                               // [mA] Irms (IPP/IPN)
float irms_set    = 0.1f;

uint8_t tx_busy = 0;

const uint32_t send_data_size = 20; 
const uint32_t buffer_size = 100;
const uint32_t value_num = 10;

typedef struct
{
  uint16_t value[10];
} value_buf_t;

value_buf_t queue_buffer[10];

qbuffer_t value_queue;




void controlUartUpdate(void);


bool controlInit(void)
{
  is_init = true;

  qbufferCreateBySize(&value_queue, (uint8_t *)queue_buffer, sizeof(value_buf_t), value_num); // 20byte * 100

  HAL_TIM_Base_Start_IT(&htim7); // period 10Khz timer
  cliAdd("ctrl", cliControl);  

  return true;
}

void lcdUpdate(void)
{
  static uint32_t pre_time = 0;

  if(millis() - pre_time >= lcd_update_period)
  {
    pre_time = millis();

    lcdClearBuffer(black);
    lcdPrintf(0, 16*0, white, "%dHz %2.1fVpp", freq, vpp_out);
    lcdPrintf(0, 16*1, white, "%1.2f %1.2f %1.2f", vrms[ADC_CH_VRMS_1], vrms[ADC_CH_VRMS_2], irms);

    lcdRequestDraw();
  }
}

uint32_t dacAvailableForWrite(void)
{
  uint32_t rx_len;
  uint32_t wr_len;

  rx_len = qbufferAvailable(&value_queue);
  wr_len = (value_queue.len - 1) - rx_len;

  return wr_len;
}

void controlMain(void)
{
  controlUartUpdate();
}

void controlUserFunc(void)
{
  // controlUserFunc


	if (istate == 0 )  // wave off
		{
			freq    = 30;
			vpp_out = 0;
		}
	if (istate == 1 )  // wave on
		{
			freq    = freq_wave ;
			vpp_out = vpp_out_wave;
		}
	if (istate == 2 )  // algo ready
		{
			if (irms > irms_set)
			{
				istate = 3;
			}

			freq    = freq_ready ;
			vpp_out = vpp_out_ready;
		}
	if (istate == 3 )  // algo set
		{
			freq    = freq_set;
			vpp_out = vpp_set_out;
		}
}

void controlAdcUpdate(void)
{
  adcVrms1UpadateProc();
  adcVrms2UpadateProc();
  adcIrms1UpadateProc();
}

void controlDacUpdate(void)
{
  static uint32_t pre_time = 0;
  static uint32_t sample_idx = 0; // sine wave 에서 생성할 현재 idx 위치.
  sample_max = control_freq / freq;

  dac_out_value = (uint16_t)rint((sinf(((2 * PI) / sample_max) * sample_idx) + 1.0f) * 2048.0f);
  dac_out_value = constrain(dac_out_value, 0, 4095);
  dac_out_value = dac_out_value * vpp_out / vpp_max;
  sample_idx    = next_idx(sample_idx, sample_max);

  HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_out_value); // DAC1 OUT
  HAL_DAC_SetValue(&hdac2, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_out_value); // DAC2 OUT

  // 일정 주기로 버퍼에 UART로 출력할 DAC 데이터를 쌓는 함수.
  if (millis() - pre_time >= 2)
  {
    pre_time = millis();

    value_buf_t buf;

    // 출력테스트를 위해 임시로 값을 채워넣는 반복문.
    //for (uint8_t i = 0; i < 10; i++)
    //{
    //  buf.value[i] = dac_out_value ;
    //}
    buf.value[0] = 100;
    buf.value[1] = dac_out_value ;
    buf.value[2] = irms*1000 ;
    buf.value[3] = istate ;
    buf.value[4] = 0 ;
    buf.value[6] = 0 ;
    buf.value[7] = 0 ;
    buf.value[8] = 0 ;
    buf.value[9] = 0 ;



    if (dacAvailableForWrite() > 0)
    {
      qbufferWrite(&value_queue, (uint8_t *)&buf, 1);
    }
  }
}

void controlUartUpdate(void)
{
  value_buf_t buf;
  if (qbufferAvailable(&value_queue) > 0)
  {
    qbufferRead(&value_queue, (uint8_t *)&buf, 1);
    HAL_UART_Transmit(&huart3, (uint8_t *)buf.value, send_data_size, 10);
  }
}

// / UART3 DMA TX 완료시 콜백함수
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{

}

// 타이머 인터럽트 콜백함수
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  // TIM7. 10Khz(100us)
  if (htim->Instance == htim7.Instance) 
  {
    controlAdcUpdate();
    controlUserFunc();
    controlDacUpdate();
  }
}

// ADC 변환 완료 콜백함수 10Khz(100us)
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  if (hadc->Instance == hadc1.Instance)
  {
    static uint8_t i = 0;

    adc_value[i] = HAL_ADC_GetValue(&hadc1);

    i = next_idx(i, adc_ch_max);
  }
}

void adcVrms1UpadateProc(void)
{
  const uint8_t ch = ADC_CH_VRMS_1;

  float adc_offset = 2369.0f;
  float adc_max    = 4090.0f;
  float adc_min    = 0.0f;
  float adc_range  = 0.0f;
  float value      = 0.0f;

  static float    sum = 0.0f;
  static float    avg = 0.0f;
  static uint32_t cnt = 0;
  uint32_t sample_cnt = 0;


  sample_cnt = sample_max * multi_sampling_num;
  adc_range  = adc_max - adc_offset;
  adc_min    = adc_offset - adc_range;

  value = adc_value[ch];
  value = constrain(value, adc_min, adc_max);
  value = abs(value - adc_offset);
  value /= adc_range;
  sum += value;

  cnt++;
  if(cnt >= sample_cnt)
  {
    avg = sum / cnt;
    vrms[ch] = avg * vpeak_max;

    sum = 0.0f;
    cnt = 0;
  }
}

void adcVrms2UpadateProc(void)
{
  const uint8_t ch = ADC_CH_VRMS_2;

  float adc_offset = 2369.0f;
  float adc_max    = 4090.0f;
  float adc_min    = 0.0f;
  float adc_range  = 0.0f;
  float value      = 0.0f;  

  static float    sum = 0.0f;
  static float    avg = 0.0f;
  static uint32_t cnt = 0;
  uint32_t sample_cnt = 0;


  sample_cnt = sample_max * multi_sampling_num;
  adc_range  = adc_max - adc_offset;
  adc_min    = adc_offset - adc_range;

  value = adc_value[ch];
  value = constrain(value, adc_min, adc_max);
  value = abs(value - adc_offset);
  value /= adc_range;
  sum += value;

  cnt++;
  if(cnt >= sample_cnt)
  {
    avg = sum / cnt;
    vrms[ch] = avg * vpeak_max;

    sum = 0.0f;
    cnt = 0;
  }
}

void adcIrms1UpadateProc(void)
{
  const uint8_t ch = ADC_CH_IRMS_1;

  float adc_offset = 1855.0f;
  float adc_max    = 2538.0f;
  float adc_min    = 0.0f;
  float adc_range  = 0.0f;
  float value      = 0.0f;  

  static float    sum = 0.0f;
  static float    avg = 0.0f;
  static uint32_t cnt = 0;
  uint32_t sample_cnt = 0;


  sample_cnt = sample_max * multi_sampling_num;
  adc_range  = adc_max - adc_offset;
  adc_min    = adc_offset - adc_range;

  value = adc_value[ch];
  value = constrain(value, adc_min, adc_max);
  value = abs(value - adc_offset);
  value /= adc_range;
  sum += value;

  cnt++;
  if(cnt >= sample_cnt)
  {
    avg = sum / cnt;
    irms = avg * ipeak_max;

    sum = 0.0f;
    cnt = 0;
  }
}

void cliControl(cli_args_t *args)
{
  bool ret = false;

  if (args->argc == 1 && args->isStr(0, "info") == true)
  {
    cliPrintf("ctrl init : %s\n", is_init ? "OK" : "NG");
    cliPrintf("algo state : %d\n", istate);
    
    ret = true;
  }

  if (args->argc == 2 && args->isStr(0, "run") == true)
  {
    uint8_t state ;

    state = args->getData(1);


    istate = constrain(state, 0, 3);

    cliPrintf("state\n istate: %3d \n", istate);

    ret = true;
  }

  if (args->argc == 3 && args->isStr(0, "wave") == true)
  {
    uint16_t freq_tmp, prev_freq;
    float    vpp_tmp, prev_vpp;

    freq_tmp = args->getData(1);
    vpp_tmp  = args->getFloat(2);

    prev_freq = freq_wave;
    prev_vpp = vpp_out_wave;

    freq_wave = constrain(freq_tmp, 1, 200);
    vpp_out_wave = constrain(vpp_tmp, 1.0f, 20.0f);

    cliPrintf("wave update.\nfreq: %3d -> %3d hz\nvpp : %2.1f -> %2.1f vpp\n", prev_freq, freq_wave, prev_vpp, vpp_out_wave);

    ret = true;
  }

  if (args->argc == 2 && args->isStr(0, "spoint") == true)
  {
    float    irms_set_tmp, irms_set_tmp_prev;

    irms_set_tmp = args->getFloat(1);

    irms_set_tmp_prev = irms_set;
    irms_set = constrain(irms_set_tmp, 0, 2);


    cliPrintf("algo setpoint.\nirms_set : %2.3f -> %2.3f \n", irms_set_tmp_prev, irms_set_tmp);

    ret = true;
  }

  if (args->argc == 5 && args->isStr(0, "prop") == true)
  {
    uint16_t freq_tmp,freq_set_tmp;
    float    vpp_tmp, vpp_set_tmp;

    freq_tmp     = args->getData(1);
    vpp_tmp      = args->getFloat(2);
    freq_set_tmp = args->getData(3);
    vpp_set_tmp  = args->getFloat(4);


    freq_ready 		= constrain(freq_tmp, 1, 200);
    vpp_out_ready 	= constrain(vpp_tmp, 1.0f, 20.0f);
    freq_set 	    = constrain(freq_set_tmp, 1, 200);
    vpp_set_out     = constrain(vpp_set_tmp, 1.0f, 20.0f);

    cliPrintf("Algorithm setting update.\nfreq: %3d -> %3d hz\nvpp : %2.1f -> %2.1f vpp\n", freq_tmp, freq_set_tmp, vpp_tmp, vpp_set_tmp);

    ret = true;
  }

  if (ret != true)
  {
    cliPrintf("ctrl info\n");

    cliPrintf("ctrl run operation [0 or 1 or 2 or 3]\n");


    cliPrintf("operation 0 : wave mode OFF    \n");
    cliPrintf("operation 1 : wave mode ON     \n");
    cliPrintf("operation 2 : Algorithm ready  \n");
    cliPrintf("operation 3 : Algorithm set    \n");

    cliPrintf("ctrl prop freq[1-200] vpp[1.0-20.0] freq_set[1-200] vpp_set[1.0-20.0]\n");

    cliPrintf("ctrl wave freq[1-200] vpp[1.0-20.0]\n");
    cliPrintf("ctrl spoint value[0-2]\n");
  }
}
