/*
 * ap.h
 *
 *  Created on: May 2, 2024
 *      Author: jangho
 */

#ifndef AP_H_
#define AP_H_

#include "ap_def.h"
#include "control.h"

void apInit(void);
void apMain(void);

#endif /* AP_H_ */
