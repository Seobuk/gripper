/*
 * ap_def.h
 *
 *  Created on: May 2, 2024
 *      Author: jangho
 */

#ifndef AP_DEF_H_
#define AP_DEF_H_

#include "hw.h"

#endif /* AP_DEF_H_ */
