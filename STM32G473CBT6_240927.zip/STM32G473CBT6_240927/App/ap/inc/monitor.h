#ifndef AP_MONITOR_H_
#define AP_MONITOR_H_

#include "hw.h"

bool monitorInit(void);
void monitorMain(void);

#endif