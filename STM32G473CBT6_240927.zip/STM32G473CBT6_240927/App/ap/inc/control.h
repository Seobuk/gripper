#ifndef AP_CONTROL_H_
#define AP_CONTROL_H_

#include "hw.h"

bool controlInit(void);
void controlUserFunc(void);
void controlUserMain(void);

#endif /* AP_CONTROL_H_ */
